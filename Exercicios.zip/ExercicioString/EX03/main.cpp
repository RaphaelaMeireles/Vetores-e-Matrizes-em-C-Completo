#include <iostream>
#include <cstdlib>
#include <cstring>

using namespace std;

int main() {
    char str[50], strmod[50];
    int achei;

    cout << "\nEntre com a string: ";
    cin.getline(str, size(str));

    strcpy(strmod, str);

    for (int i = 0; str[i]; i++) {
        strmod[i];
        if (str[i] == 'a') {
            achei++;
            strmod[i] = 'b';
        }
    }

    cout << "\nString digitada: " << str;
    cout << "\nForam modificados " << achei << " caracteres.";
    cout << "\nString modificada: " << strmod;
    cout << "\n";

    system("pause");
    return 0;
}
