#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

int main() {
    char cargo[30];
    float salario_antigo, salario_novo = 0, diferença = 0, porcentagem = 0;

    cout << "Digite seu cargo: ";
    cin.getline(cargo, size(cargo));

    cout << "Digite seu salario: ";
    cin >> salario_antigo;

    if(stricmp(cargo, "Gerente") == 0){
        porcentagem = 10;
        diferença = porcentagem/100 * salario_antigo;
        salario_novo = diferença + salario_antigo;
    }

    else if(stricmp(cargo, "Engenheiro") == 0){
        porcentagem = 20;
        diferença = porcentagem/100 * salario_antigo;
        salario_novo = diferença + salario_antigo;
    }

    else if(stricmp(cargo, "Tecnico") == 0){
        porcentagem = 30;
        diferença = porcentagem/100 * salario_antigo;
        salario_novo = diferença + salario_antigo;
    } else {
        porcentagem = 5;
        diferença = porcentagem/100 * salario_antigo;
        salario_novo = diferença + salario_antigo;
    }

    cout << "\nSalario antigo: " << salario_antigo;
    cout << "\nSalario novo: " << salario_novo;
    cout << "\nDiferenca: " << diferença;
    cout << "\n";

    system("pause");
    return 0;
}
