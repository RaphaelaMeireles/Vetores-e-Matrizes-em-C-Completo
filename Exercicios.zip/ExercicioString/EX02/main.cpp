#include <iostream>
#include <cstring>

using namespace std;

int main() {
    char str1[50], str2[50];
    int ultima;

    cout << "\nEntre com a primeira string: ";
    cin.getline(str1, size(str1));

    cout << "\nEntre com a segunda string: ";
    cin.getline(str2, size(str2));

    cout << "\nString 1: " << str1 << "\n" << "String 2: " << str2;

    cout << "\nSegunda letra da primeira string: " << str1[1];
    ultima = strlen(str2);
    cout << "\nPenultima letra da segunda string: " << str2[ultima - 2];

    return 0;
}
