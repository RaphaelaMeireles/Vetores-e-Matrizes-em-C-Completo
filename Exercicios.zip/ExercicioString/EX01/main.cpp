#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;


int main() {
    char nomes[50], maior[50], menor[50];

    while (1) {
        cout << "Digite um nome ou aperte enter para sair: ";
        cin.getline(nomes, size(nomes));

        if (strlen(nomes) == 0) {
            break;
        }

        for (int i = 0; i < nomes[i]; ++i) {
            maior == "a";
            maior == strcat (maior, nomes);

            if (strcmp(nomes, maior) < 0){
                menor == strcpy(menor, nomes);
            }
        }
    }
    cout << menor;

    system("pause");
    return 0;
}