#include <iostream>
using namespace std;
int main() {
    int num[10], tamanho, maior1 = 0, maior2 = 0, soma = 0;

    cout << "Digite quantos elementos voce deseja:";
    cin >> tamanho;
    cout << "\n";

    while (tamanho > 10){
        cout << "O tamanho deve ser menor que 10 ... Digite quantos elementos voce deseja:";
        cin >> tamanho;
        cout << "\n";
    }

    for (int i = 0; i < tamanho; ++i) {
        cout << "Digite um numero: ";
        cin >> num[i];
    }

    for (int i = 0; i < tamanho; ++i) {
        if (num[i] > maior1){
            maior2 = maior1;
            maior1 = num[i];
        }
        else if (num[i] > maior2){
            maior2 = num[i];
        }
    }

    for (int i = 0; i < tamanho; ++i) {
        if ( i%2 != 0) {
            if (num[i]%2 == 0) {
                soma += num[i];
            }
        }
    }

    cout << "\n O primeiro maior numero eh " << maior1 << " e o segundo maior numero eh " << maior2 << "\n";
    cout << "\n A soma dos elementos pares em posicoes impares sera: " << soma << "\n";

    system("pause");
    return 0;
}
