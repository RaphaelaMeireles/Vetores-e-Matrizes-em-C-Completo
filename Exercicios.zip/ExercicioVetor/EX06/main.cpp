#include <iostream>
using namespace std;

int main() {
    int matriz_1[20][25];
    int multiplicação[20][25];
    int transposta[20][25];
    int matriz_2[20][25];
    int M, N, K;

    cout << "Informe em numeros inteiros ate 20 o tamanho da matriz que deseja utilizar: ";
    cin >> M;

    while(M > 20 || M <= 0) {
        cout << "Insira um numero de 1 a 20: ";
        cin >> M;
    }

    cout << "Informe em numeros inteiros ate 25 a quantidade de colunas que deseja utilizar:  ";
    cin >> N;

    while(N > 25 || N <= 0) {
        cout << "Insira um numero de 1 a 25: ";
        cin >> N;
    }

    cout << "Digite os valores da primeira matriz:\n";
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "Posicao [" << i << "][" << j << "] : ";
            cin >> matriz_1[i][j];
        }
    }

    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            transposta[j][i] = matriz_1[i][j];
        }
    }

    cout << "Insira o fator 'K' para fazer a multiplicacao:\n ";
    cin >> K;

    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            multiplicação[i][j] = matriz_1[i][j] * K;
        }
    }

    cout << "Digite os valores da segunda matriz para a adicao:\n";
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "Posicao [" << i << "][" << j << "] : ";
            cin >> matriz_2[i][j];
        }
    }

    cout << "\n1- Matriz Transposta:\n";
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < M; j++) {
            cout << "[" << transposta[i][j] << "]\t";
        }
        cout <<"\n";
    }

    cout <<"\n2- Calculo da matriz por um fator K informado:\n";
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "[" << multiplicação[i][j] << "]\t";
        }
        cout << "\n";
    }

    cout << "\n3- Adicao com a segunda matriz informada:\n";
    for(int i = 0; i < M; i++) {
        for(int j = 0; j < N; j++) {
            cout << "[" << matriz_1[i][j] + matriz_2[i][j] << "]\t";
        }
        cout << "\n";
    }
    return 0;
}