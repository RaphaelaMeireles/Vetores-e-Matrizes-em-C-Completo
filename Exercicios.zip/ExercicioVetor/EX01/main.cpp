#include <iostream>
using namespace std;

int main() {
    int num[5];
    int impar = 0;

    for (int i = 0; i < 5; i++) {
        cout << "Digite um numero:";
        cin >> num[i];
        if (num[i]%2 != 0) {
            impar += num[i];
        }
    }
    cout<< "A soma e:" << impar;
    return 0;
}
