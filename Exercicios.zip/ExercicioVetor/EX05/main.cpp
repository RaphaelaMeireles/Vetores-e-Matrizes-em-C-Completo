#include <iostream>
using namespace std;

int main()
{
    int V1[10],V2[10], i = 0;

    for (i = 0; i < 10; ++i) {
        cout << " Digite um numero inteiro: ";
        cin >> V1[i];
        V2[i] = V1[i];
    }

    for (i = 0; i < 10; ++i) {
        if (i%2 == 0) {
        V2[i] = V2[i] * 5;
        }
        else if (i%2 != 0) {
            V2[i] = V2[i] + 5;
        }
    }

    cout << "\n --------------------------------------------";
    cout <<"\n Vetor 1: \n";
    for (i = 0; i < 10; ++i) {
        cout << V1[i] << " ";
    }
    cout <<"\n Vetor 2: \n";
    for (i = 0; i < 10; ++i) {
        cout << V2[i] << " ";
    }

    system("pause");
    return 0;
}
