#include <iostream>
using namespace std;

int main() {
    int produtos[5];
    float valorun[5] = {1.00,2.00,5.50,10.90,20.30 };
    float multi;
    float valortotal;
    for (int i = 0; i < 5; ++i) {
        cout << "Quantidade do Produto " << i << ":";
        cin >> produtos[i];
    }
    for (int i = 0; i < 5; ++i) {
        multi = produtos[i] *  valorun[i];
        valortotal += multi;
        cout << "O produto " << i << " esta saindo por R$" << valorun[i] << "\n";
    }
    cout << "-----------------------------------\n VALOR TOTAL: " << valortotal;

    return 0;
}
