#include <cmath>
#include <iostream>
using namespace std;

int main() {
    float notas[5], media, desvios[5], variancia[5], soma = 0, raiz = 0;
    for (int i = 0; i < 5; ++i) {
        cout << "Digite a nota do aluno " << i << ": ";
        cin >> notas[i];
        soma += notas[i];
    }
    media = soma/5;
    cout << "--------------------------------------\n" <<"A media dessa turma eh de " << media << "\n";

    soma = 0;
    for (int i = 0; i < 5; ++i) {
        variancia[i] = pow(notas[i] - media, 2);
        soma += variancia[i];
        }

    for (int i = 0; i < 5; ++i) {
        desvios[i] = variancia[i];
        raiz += desvios[i];
    }

    raiz = raiz/5;
    desvios[5] = sqrt(raiz);
    variancia[5] = soma/5;

    cout << "A turma esta com desvio de " << desvios[5] << " variancia de " << variancia[5] <<"\n";
    return 0;
}
